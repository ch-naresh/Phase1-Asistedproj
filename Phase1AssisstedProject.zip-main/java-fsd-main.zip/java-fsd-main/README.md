# java-fsd
Practice project for Java
