package accessmodifiers;

public class DefaultMain {

}
