package accessmodifiers;

public class PublicA {
	public void display() 
    { 
        System.out.println("This is Public Access Specifiers"); 
    } 

}