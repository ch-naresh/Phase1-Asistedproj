package accessmodifiers;

public class accessmodifiers {

}
