package accessmodifiers;

public class ProtectedA {
	protected void msg()
	{
		System.out.println("Protected is using");
		}  
}
