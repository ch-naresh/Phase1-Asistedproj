package whileloop;

public class Whileloop {
	
	public static void main(String args[])
    {
        // initialization expression
        int i = 1;
 
        // test expression
        while (i < 6) {
            System.out.println("Hello World");
 
            // update expression
            i++;
        }
    }

}
